void KEYB_Init(void);
char KEYB_Input(void);

extern unsigned char LCD_line, LCD_col;