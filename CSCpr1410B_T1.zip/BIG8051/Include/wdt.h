// Prototipuri functii de lucru cu ceasul de garda

void WDT_Disable(void);
void WDT_Restart(void);
void WDT_Lock(void);
int WDT_Status(void);
